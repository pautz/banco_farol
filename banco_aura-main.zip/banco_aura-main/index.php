<?php
// 🔒 Redirecionar para HTTPS se necessário
if (!isset($_SERVER['HTTPS']) || $_SERVER['HTTPS'] !== 'on') {
    $url = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header('Location: ' . $url);
    exit();
}
// Verifica se o cookie já foi definido

// 🛡️ Cabeçalhos de segurança
header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN'); // Corrigido: não pode ter dois X-Frame-Options
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: no-referrer');
header("Content-Security-Policy: frame-ancestors 'self' https://carlitoslocacoes.com;");
header("X-Powered-By: MeuServidorPHP");

// 🌐 Verifica cabeçalho personalizado do CloudFront
if (isset($_SERVER['HTTP_X_CUSTOM_HEADER'])) {
    echo "Cabeçalho personalizado recebido: " . htmlspecialchars($_SERVER['HTTP_X_CUSTOM_HEADER']);
}

// 📦 Conexão com o banco
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/web3@1.7.5/dist/web3.min.js"></script>
  <title>Carlito's Locações</title>
    <meta name="description" content="Locação de tratores em Palmeira das Missões - RS. Encontre tratores de qualidade para sua necessidade! Trabalhamos com linha de transmissão, oferecendo equipamentos robustos e eficientes. Estamos na Av Independência, N 877, Sala 02, Palmeira Das Missões, Rio Grande Do Sul, Brasil. CEP: 98300-000. Acesse carlitoslocacoes.com">
    <meta name="keywords" content="trator, óleo, aeroportos, Palmeira das Missões, locação de tratores, linha de transmissão, locação de máquinas, retroescavadeiras, equipamentos pesados, aluguel de máquinas, sistema de controle de óleo, sistema de caixa, pagamentos de prestações, locação de quartos">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="robots" content="index, follow">
  <meta name="author" content="Carlito Veeck Pautz Júnior">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
  <link rel="icon" type="image/x-icon" href="https://carlitoslocacoes.com/site2/favico.png">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
 <nav class="navbar">
  <div class="navbar-logo">Carlito's Locações</div>

  <input type="checkbox" id="menu-toggle">
  <label for="menu-toggle" class="menu-icon">&#9776;</label>

  <ul class="navbar-links">
    <li><a href="https://api.whatsapp.com/send?phone=5555996479747" target="_blank">
      📞 +55 55 99647-9747
    </a></li>
  </ul>
</nav>


<style>:root {
  --cor-primaria: #007bff;
  --cor-secundaria: #f8f9fa;
  --cor-destaque: #00c6ff;
  --cor-texto: #333;
  --cor-fundo: #ffffff;
  --sombra: 0 4px 12px rgba(0,0,0,0.1);
  --borda-radius: 12px;
  --transicao: 0.3s ease;
  --fonte-principal: 'Montserrat', 'Segoe UI', sans-serif;
}

/* Reset */
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

body {
  font-family: var(--fonte-principal);
  background-color: var(--cor-secundaria);
  color: var(--cor-texto);
  line-height: 1.6;
  overflow-x: hidden;
}

/* === NAVBAR === */
.navbar {
  position: sticky;
  top: 0;
  width: 100%;
  background: rgba(0, 0, 0, 0.7);
  backdrop-filter: blur(8px);
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 20px;
  z-index: 100;
}

.navbar-logo {
  font-size: 1.5rem;
  font-weight: bold;
  color: var(--cor-destaque);
  text-shadow: 0 0 6px var(--cor-destaque);
}

.navbar-links {
  display: flex;
  list-style: none;
  gap: 20px;
  flex-wrap: wrap;
}

.navbar-links li a {
  color: #fff;
  text-decoration: none;
  font-weight: 500;
  font-size: 16px;
  transition: color var(--transicao), text-shadow var(--transicao);
}

.navbar-links li a:hover {
  color: var(--cor-destaque);
  text-shadow: 0 0 6px var(--cor-destaque);
}

.menu-icon {
  display: none;
  font-size: 24px;
  color: #fff;
  cursor: pointer;
}

#menu-toggle {
  display: none;
}

@media (max-width: 768px) {
  .navbar {
    flex-wrap: wrap;
  }

  .menu-icon {
    display: block;
  }

  .navbar-links {
    flex-direction: column;
    width: 100%;
    display: none;
    margin-top: 10px;
  }

  #menu-toggle:checked + .menu-icon + .navbar-links {
    display: flex;
  }

  .navbar-links li {
    padding: 10px 0;
  }
}

/* === CONTAINER PRINCIPAL === */
.container_sistema {
  background-color: var(--cor-fundo);
  border-radius: var(--borda-radius);
  box-shadow: var(--sombra);
  padding: 40px 20px;
  max-width: 600px;
  margin: 60px auto;
  text-align: center;
}

/* === FORMULÁRIO PIX === */
form {
  width: 100%;
}

label {
  font-weight: bold;
  display: block;
  margin-bottom: 6px;
  text-align: left;
}

input[type="text"],
input[type="range"] {
  width: 100%;
  padding: 10px;
  margin-bottom: 15px;
  border-radius: 6px;
  border: 1px solid #ccc;
  font-size: 16px;
}

button {
  background-color: var(--cor-primaria);
  color: #fff;
  border: none;
  padding: 12px 20px;
  border-radius: 6px;
  transition: background-color var(--transicao);
  width: 100%;
  font-weight: bold;
  font-size: 16px;
}

button:hover {
  background-color: #0056b3;
}

/* === BOTÕES DE ACESSO === */
.container_sys {
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
  justify-content: center;
  padding: 20px;
  font-family: Arial, sans-serif;
}

.btn-acessar-site {
  flex: 1 1 200px;
  max-width: 250px;
  text-align: center;
  background: #00aaff;
  color: #fff;
  font-weight: bold;
  text-decoration: none;
  padding: 12px 18px;
  border-radius: 8px;
  transition: background 0.3s ease, transform 0.2s ease;
  display: inline-block;
  box-shadow: 0 4px 10px rgba(0,0,0,0.1);
}

.btn-acessar-site:hover {
  background: #0088cc;
  transform: translateY(-3px);
}

/* Responsividade dos botões */
@media (max-width: 768px) {
  .btn-acessar-site {
    flex: 1 1 45%;
    max-width: 100%;
    font-size: 15px;
    padding: 12px;
  }
}

@media (max-width: 480px) {
  .btn-acessar-site {
    flex: 1 1 100%;
    max-width: 100%;
    font-size: 14px;
    padding: 10px;
  }
}

/* === CARDS DE MARCAS === */
.cards-marcas {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 20px;
  margin: 40px auto;
  padding: 0 20px;
}

.card-marca {
  width: 220px;
  max-width: 100%;
  text-align: center;
  text-decoration: none;
  border: 2px solid #ccc;
  border-radius: 10px;
  padding: 15px;
  background-color: var(--cor-fundo);
  box-shadow: var(--sombra);
  transition: transform var(--transicao), border-color var(--transicao);
}

.card-marca:hover {
  transform: scale(1.05);
  border-color: var(--cor-primaria);
}

.card-marca img {
  width: 100%;
  height: auto;
  border-radius: 8px;
  object-fit: cover;
}

.card-marca span {
  display: block;
  margin-top: 10px;
  font-size: 16px;
  font-weight: bold;
  color: var(--cor-texto);
}

@media (max-width: 768px) {
  .card-marca {
    width: 45%;
  }
}

@media (max-width: 480px) {
  .card-marca {
    width: 100%;
  }
}

/* === FOOTER === */
.footer-localizacao {
  background-color: #222;
  color: #eee;
  padding: 30px 0;
  border-top: 4px solid var(--cor-destaque);
  font-family: var(--fonte-principal);
  text-align: center;
}

.footer-localizacao p {
  margin: 0;
  line-height: 1.6;
  font-size: 15px;
}

.footer-localizacao .text-muted {
  color: #aaa;
}

/* === POPUP TWITCH === */
.popup-overlay {
  position: fixed;
  top: 0; left: 0;
  width: 100%; height: 100%;
  background: rgba(0,0,0,0.6);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999;
}

.popup-content {
  background: #000;
  padding: 0;
  border-radius: 8px;
  width: 800px;
  height: 450px;
  position: relative;
  box-shadow: 0 0 20px rgba(0,0,0,0.8);
}

.popup-content iframe {
  width: 100%;
  height: 100%;
  border: none;
  border-radius: 8px;
}

.close-btn {
  position: absolute;
  top: 10px;
  right: 10px;
  background: #fff;
  color: #000;
  border: none;
  font-weight: bold;
  padding: 5px 10px;
  cursor: pointer;
  border-radius: 4px;
  z-index: 10000;
}

/* === EFEITO DE NEVE === */
/* === EFEITO DE NEVE === */
.snowflake {
  color: #fff;
  font-size: 1em;
  font-family: Arial;
  text-shadow: 0 0 1px #000;
  position: fixed;
  top: -10%;
  z-index: 9999;
  user-select: none;
  cursor: default;
  animation-name: snowflakes-fall, snowflakes-shake;
  animation-duration: 10s, 3s;
  animation-timing-function: linear, ease-in-out;
  animation-iteration-count: infinite, infinite;
}

@keyframes snowflakes-fall {
  0% { top: -10%; }
  100% { top: 100%; }
}

@keyframes snowflakes-shake {
  0% { transform: translateX(0px); }
  50% { transform: translateX(80px); }
  100% { transform: translateX(0px); }
}

/* === PARTICLES BACKGROUND === */
#particles-js {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  z-index: -1;
  background-color: transparent;
  overflow: hidden;
}

/* === CONTAINER DE CARDS SECUNDÁRIOS === */
.container_sistema2 {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  justify-content: center;
  font-family: Arial, sans-serif;
  padding: 20px;
}

.container_sistema2 .card {
  flex: 1 1 250px;
  max-width: 320px;
  background: #fff;
  border-radius: 12px;
  border: 1px solid #ddd;
  overflow: hidden;
  text-align: center;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
  cursor: pointer;
}

.container_sistema2 .card:hover {
  transform: translateY(-5px);
  box-shadow: 0 6px 12px rgba(0,0,0,0.15);
}

.container_sistema2 img {
  width: 100%;
  height: auto;
  display: block;
}

.container_sistema2 pre {
  background: #f6f8fa;
  padding: 10px;
  border-top: 1px solid #e1e4e8;
  margin: 0;
  font-size: 14px;
}
</style>


</head>
<body>
    
 <div id="particles-js">

<script src="https://cdnjs.cloudflare.com/ajax/libs/particles.js/2.0.0/particles.min.js"></script>

  <script>
        /* Configuração do Particles.js */
        particlesJS("particles-js", {
            particles: {
                number: {
                    value: 100,
                    density: { enable: true, value_area: 800 }
                },
                color: { value: "#333333" }, // Cor escura para as partículas
                shape: {
                    type: "circle",
                    stroke: { width: 0, color: "#000000" },
                    polygon: { nb_sides: 5 }
                },
                opacity: {
                    value: 0.7, // Transparência das partículas
                    random: false,
                    anim: { enable: false, speed: 1, opacity_min: 0.1, sync: false }
                },
                size: {
                    value: 5,
                    random: true,
                    anim: { enable: false, speed: 40, size_min: 0.1, sync: false }
                },
                line_linked: {
                    enable: true,
                    distance: 150,
                    color: "#333333", // Cor escura para as linhas
                    opacity: 0.5, // Transparência das linhas
                    width: 1
                },
                move: {
                    enable: true,
                    speed: 6,
                    direction: "none",
                    random: false,
                    straight: false,
                    out_mode: "out",
                    bounce: false,
                    attract: { enable: false, rotateX: 600, rotateY: 1200 }
                }
            },
            interactivity: {
                detect_on: "canvas",
                events: {
                    onhover: { enable: true, mode: "grab" },
                    onclick: { enable: true, mode: "push" },
                    resize: true
                },
                modes: {
                    grab: { distance: 200, line_linked: { opacity: 1 } },
                    bubble: { distance: 400, size: 40, duration: 2, opacity: 8, speed: 3 },
                    repulse: { distance: 200, duration: 0.4 },
                    push: { particles_nb: 4 },
                    remove: { particles_nb: 2 }
                }
            },
            retina_detect: true
        });
    </script>
  
  <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-17093753122">
</script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-17093753122');
</script>

</div>


<div class="container_sistema">
  

    <h2>📲 Comprar Aura via Pix</h2>
  <form method="POST" action="site2/pix_aura/gerar_pix.php">
    <label>📮 Caixa Postal:</label>
    <input type="text" name="caixa_postal" required />

    <label>💰 Quantidade de Aura:</label>
    <input type="range" min="5" max="500000" step="5" value="5"
           id="sliderAura" name="aura" oninput="atualizarValor()" />
    <span id="valorAura">5</span> aura (<span id="valorReais">5</span> R$)

    <input type="hidden" name="valor_reais" id="valorReaisHidden" value="160" />
    <button type="submit">💳 Gerar Pix</button>
  </form><br>
        </div>
    <div class="container_sys">
  <a href="https://carlitoslocacoes.com/farolqr/site/identificacao_farolqr.php" class="btn-acessar-site" target="_blank">🌐 Identificação</a>
  <a href="https://carlitoslocacoes.com/farolqr/site/balance_transacao.php" class="btn-acessar-site" target="_blank">🌐 Banco</a>
</div>

  


  <script>
    function fecharPopup() {
      document.getElementById("popupTwitch").style.display = "none";
    }
  </script>
<script>
function atualizarValor() {
  const valor = parseInt(document.getElementById("sliderAura").value);
  const reais = (valor * 1).toFixed(2);
  document.getElementById("valorAura").textContent = valor;
  document.getElementById("valorReais").textContent = reais.replace('.', ',');
  document.getElementById("valorReaisHidden").value = reais;
}
</script>


<script>
$(document).ready(function() {
  $("#carregar-valtra").on("click", function(e) {
    e.preventDefault(); // impede o comportamento padrão do link

    $.ajax({
      url: "https://carlitoslocacoes.com/containers.php",
      type: "GET",
      data: { idtrator: "valtra" },
      success: function(response) {
        $("#resultado-valtra").html(response);
      },
      error: function(xhr, status, error) {
        $("#resultado-valtra").html("<p>Erro ao carregar conteúdo.</p>");
        console.error("Erro AJAX:", error);
      }
    });
  });
});
</script>


<footer class="footer-localizacao">
  <div class="container text-center py-4">
    <p>📍 Av Independência, N 877, Sala 02<br>
    Palmeira Das Missões, Rio Grande Do Sul, Brasil<br>
    CEP: 98300-000<br>
    +55 55 99647-9747</p><br>
    CNPJ: 18.658.210.0001.37 <BR>
    <p class="text-muted small">© <?= date('Y') ?> Carlito's Locações</p>
  </div>
</footer>



  

    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.13.216/pdf.min.js"></script>
<!-- Footer -->


</body>
</html>
