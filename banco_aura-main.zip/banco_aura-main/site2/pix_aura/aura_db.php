<?php
$host = 'localhost';
$user = 'u839226731_cztuap';
$pass = 'Meu6595869Trator';
$db   = 'u839226731_meutrator';

$cx = new mysqli($host, $user, $pass, $db);

if ($cx->connect_error) {
  die('Erro na conexão: ' . $cx->connect_error);
}

$cx->set_charset("utf8mb4");
