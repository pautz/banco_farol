<?php
require 'aura_db.php';

$caixa = $_POST['caixa_postal'] ?? '';
$aura  = intval($_POST['aura'] ?? 0);

if (!$caixa || $aura < 5 || $aura > 100000 || $aura % 5 !== 0) {
    die("⚠️ Dados inválidos.");
}


// Cálculo seguro do valor
$preco_por_aura = 1; // R$2,40 por aura
$reais = $aura * $preco_por_aura;

$access_token = 'APP_USR-4181749501270506-040914-3a36aa961fcb7111ee4cf0bd0fa3524f-157818820';
$unique_id = uniqid('pix_', true);
$descricao = "FarolQR - Estudos em carlitoslocacoes.com compra de $aura aura para caixa postal $caixa";

$dados = [
    'transaction_amount' => $reais,
    'description' => $descricao,
    'payment_method_id' => 'pix',
    'payer' => [
        'email' => 'cliente@email.com',
        'first_name' => 'Cliente',
        'last_name' => 'Aura'
    ]
];

$ch = curl_init('https://api.mercadopago.com/v1/payments');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($dados));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . $access_token,
    'Content-Type: application/json',
    'X-Idempotency-Key: ' . $unique_id
]);
$resposta = curl_exec($ch);
curl_close($ch);

$resultado = json_decode($resposta, true);
$pix_id = $resultado['id'] ?? '';
$transacao = $resultado['point_of_interaction']['transaction_data'] ?? null;
$qr = $transacao['qr_code_base64'] ?? '';
$link = $transacao['ticket_url'] ?? '';
$copiacola = $transacao['qr_code'] ?? '';

// Salva no banco
$stmt = $cx->prepare("INSERT INTO pedidos_aura 
  (caixa_postal, quantidade, valor_reais, pix_id, unique_id, copia_cola, link_pix, status) 
  VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

$status = 'pendente';
$stmt->bind_param("sidsssss", $caixa, $aura, $reais, $pix_id, $unique_id, $copiacola, $link, $status);
$stmt->execute();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Pagamento Pix - Aura</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    * { box-sizing: border-box; }
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f9f9f9;
      margin: 0;
      padding: 20px;
      text-align: center;
      color: #333;
    }
    .container {
      max-width: 500px;
      margin: auto;
      background: #fff;
      padding: 25px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.05);
    }
    h2 { margin-bottom: 10px; color: #444; }
    .info p { margin: 8px 0; font-size: 1rem; }
    .qr img {
      width: 100%;
      max-width: 300px;
      height: auto;
      margin: 20px 0;
      border-radius: 8px;
    }
    .copiar {
      background: #f0f0f0;
      padding: 12px;
      border-radius: 6px;
      word-break: break-word;
      font-size: 0.95rem;
      margin-bottom: 10px;
    }
    button {
      background-color: #4CAF50;
      color: white;
      border: none;
      padding: 12px 20px;
      font-size: 1rem;
      border-radius: 6px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }
    button:hover { background-color: #45a049; }
    a {
      display: inline-block;
      margin-top: 15px;
      color: #0077cc;
      text-decoration: none;
      font-weight: bold;
    }
    a:hover { text-decoration: underline; }
    @media (max-width: 600px) {
      .container { padding: 15px; }
      .copiar { font-size: 0.9rem; }
      button { width: 100%; }
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Pagamento via Pix</h2>
    <div class="info">
      <p>📦 Caixa Postal: <strong><?= htmlspecialchars($caixa) ?></strong></p>
      <p>✨ Aura: <strong><?= $aura ?></strong></p>
      <p>💰 Valor: <strong>R$ <?= number_format($reais, 2, ',', '.') ?></strong></p>
    </div>

    <?php if ($qr): ?>
      <div class="qr">
        <img src="data:image/png;base64,<?= $qr ?>" alt="QR Code Pix">
      </div>
    <?php endif; ?>

    <?php if ($copiacola): ?>
      <div class="copiar" id="pixCode"><?= htmlspecialchars($copiacola) ?></div>
      <button onclick="copiarPix()">📋 Copiar código Pix</button>
    <?php endif; ?>

    <?php if ($link): ?>
      <a href="<?= htmlspecialchars($link) ?>" target="_blank">🔗 Abrir link do pagamento</a>
    <?php endif; ?>
  </div>

  <script>
    function copiarPix() {
      const texto = document.getElementById("pixCode").innerText;
      navigator.clipboard.writeText(texto).then(() => {
        alert("✅ Código Pix copiado!");
      });
    }
  </script>
</body>
</html>
